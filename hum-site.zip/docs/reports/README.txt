Put report PDFs here: proposal.pdf, checkpoint.pdf, final.pdf, summary.pdf
